package com.example.usuario.fepx;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }
    public void startLineup(View view){
        Intent lineUpInt=new Intent(Menu.this, Lineup.class);
        startActivity(lineUpInt);

    }
    public void startEscenarios(View view){
        Intent defInt=new Intent(Menu.this, Default.class);
        startActivity(defInt);
    }
    public void startParches(View view){
        Intent defInt=new Intent(Menu.this, Default.class);
        startActivity(defInt);
    }
    public void startPersonas(View view){
        Intent perInt=new Intent(Menu.this, Personas.class);
        startActivity(perInt);
    }
    public void startGuia(View view){
        Intent defInt=new Intent(Menu.this, Default.class);
        startActivity(defInt);
    }
    public void startMapa(View view){
        Intent defInt=new Intent(Menu.this, Default.class);
        startActivity(defInt);
    }


}
