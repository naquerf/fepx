package com.example.usuario.fepx;

import android.content.Intent;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.DriverManager;

public class Main extends AppCompatActivity {

    private EditText nombre;
    private EditText contrasenia;
    private Button ingreso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nombre = (EditText)findViewById(R.id.name);
        contrasenia = (EditText)findViewById(R.id.passw);
        ingreso=(Button)findViewById(R.id.button);
        ingreso.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                conexionPostgres();
                login(nombre.getText().toString(),contrasenia.getText().toString());
            }
        });
    }

    public Connection conexionPostgres(){
        Connection conexion=null;
        try{
            StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            Class.forName("org.postgresql.Driver").newInstance();
            String Host = "ec2-23-23-247-222.compute-1.amazonaws.com";
            String Database = "dct0acjmjiodag";
            String User = "qgbqxyufsdzgne";
            String Port = "5432";
            String Password = "643c7698881660a602e63a71738c4e382693eccce7cc1562778af65e1492d4fd";
            String URL = "jdbc:postgresql://" + Host + ":" + Port + "/" + Database + "?sslmode=require";
            conexion =  DriverManager.getConnection(URL, User, Password);
        }catch(Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
        }
        return conexion;
    }

    public void login(String name, String pass) {
        if ( (name.equals("user1")) && (pass.equals("abcd"))) {
            Intent intent = new Intent(Main.this, Menu.class);
            startActivity(intent);
        }
else{
            Toast.makeText(this, "usuario o contraseña incorrecta",Toast.LENGTH_SHORT).show();

        }

    }
}
